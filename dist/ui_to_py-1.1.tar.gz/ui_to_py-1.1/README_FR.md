# pyqt-gui

Un interface graphique qui facilite la conversion de fichier ui à py utilisant la fonction pyuic5

L'interphase peut aussi créer un canevas pour un projet pyqt5 et ajouter un nouveau widget à un projet déjà établi
