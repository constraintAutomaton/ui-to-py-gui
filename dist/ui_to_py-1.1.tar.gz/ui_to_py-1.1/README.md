# pyqt-gui

A user interface to facilitate the conversion ui file to py file using pyuic5 function.

The interface can also build a frame code to start a new gui project and can also add a new widget in an existing project
